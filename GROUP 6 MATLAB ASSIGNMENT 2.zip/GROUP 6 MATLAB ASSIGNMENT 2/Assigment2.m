 A = readtable('C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\DETAILS OF AMI STUDENTS.xlsx');
 B = readtable('C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\AMI1 RESULTS FOR SEMESTER ONE.xlsx');
c = readtable('C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\AMI1 RESULTS FOR SEMESTER TWO.xlsx');
 A.ASSOCIATION = categorical(strtrim(string(A.ASSOCIATION)));
 A.TRIBE = categorical(strtrim(string(A.TRIBE))); 
 
 h = heatmap(A, 'ASSOCIATION', 'TRIBE');
 h.Title = 'association vs tribes';
saveas(h,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\HEATMAP1.png');
disp('saving done');

P = figure
A.RESIDENCE = categorical(strtrim(string(A.RESIDENCE)));
pie(A.RESIDENCE);
title('A piechart showing Students residence');
saveas(P,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Piechart1.png');

B=figure('Name','BAR');
X=A.NAMEOFSTUDENT;
Y=A.AGE;
bar(X,Y);
xlabel('NAMEOFSTUDENT');
ylabel('AGE');
title('A BAR GRAPH SHOWING AGES OF AMI CLASS');
saveas(B,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\bargraph1.png');

A.AGE = double(A.AGE);
M= figure;
histogram(A.AGE)
title(['age distribution'])
xlabel('age(years)')
ylabel('number of students')
saveas(M,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\histogram1.png');

A.GENDER = categorical(A.GENDER);
A.TRIBE = categorical(A.TRIBE);
A.ASSOCIATION = categorical(A.ASSOCIATION);
A.RESIDENCE = categorical(A.RESIDENCE);

 N = figure;
histogram(A.TRIBE);
title('Bar Graph - Tribe');
xlabel('Tribe');
ylabel('Count');
saveas(N,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\histogram2.png');

Q = figure;
[c,n]=groupcounts(A.ASSOCIATION);
barh(c);
set(gca,'YTickLabel',n);
title('Horizontal Bar - Association');
saveas(Q,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\barh.png');

R=figure;
pie(A.GENDER);
title('Pie - Gender');
saveas(R,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Piechart2.png');

S=figure;
[c,n]=groupcounts(A.GENDER);
pie(c, [], string(n));
title('Pie with % - Gender');
saveas(S,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Piechart3.png');

T=figure;
histogram(A.TRIBE);
saveas(T,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\histogram3.png');

U=figure;
[c,n]=groupcounts(A.TRIBE);
pareto(c, string(n));
title('Pareto - Tribe');
saveas(U,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\pareto.png');

V=figure;
histogram(A.AGE, 8);
title('Histogram - Age');
xlabel('Age');
ylabel('Students');
saveas(V,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\histogram4.png');


W=figure;
boxplot(A.AGE, A.TRIBE);
title('BoxPlot - Age by Tribe');
saveas(W,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\boxplot1.png');

X=figure;
boxplot(A.AGE, A.GENDER);
title('Box Plot - Age by Gender');
A_sorted = sortrows(A, 'AGE');
saveas(X,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\boxplot2.png');


L=figure;
g = groupsummary(A, 'GENDER', {'mean','std'}, 'AGE');
errorbar(1:height(g), g.mean_AGE, g.std_AGE, 'o', 'LineWidth',2);
set(gca,'XTickLabel',g.GENDER); title('Error Bar - Mean Age by Gender');
ylabel('Age');
saveas(L,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\ERROR BAR PLOT.png');

I=figure;
plot(A.AGE, '-o', 'LineWidth', 2);
title('Line Plot - Age by students');
xlabel("STUDENTS");
ylabel('Age');
saveas(I,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Line Plot.png');


C=figure;
stem(A.AGE, 'filled');
title('Stem Plot - Age by students');
xlabel("STUDENTS");
ylabel('Age');

saveas(C,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Stem Plot.png');


E=figure;
stairs(A.AGE, 'LineWidth', 2);
title('Step Plot - Age by students');
xlabel('STUDENTS');
ylabel('Age');
saveas(E,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Step Plot.png');


G=figure;
errorbar(A.AGE, ones(height(A),1)*1.5, 'o-', 'LineWidth', 1.5);
title('Error Bar - Age by student');
xlabel('STUDENTS');
ylabel('Age');
saveas(G,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Error Bar.png');


F=figure;
semilogy(A.AGE, '-s', 'LineWidth', 2);
title('Logarithmic Plot - Age by student');
xlabel('STUDENTS');
ylabel('Age (log scale)');
saveas(F,'C:\Users\gh\OneDrive\Desktop\GROUP 6 MATLAB ASSIGNMENT 2\Logarithmic Plot.png');

