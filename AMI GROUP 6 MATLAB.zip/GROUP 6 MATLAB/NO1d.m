%% VISUALISATION OF A BAR GRAPH %%

Q=figure('Name','BAR');
X=A.NAMEOFSTUDENT;
Y=A.AGE;
bar(X,Y);
xlabel('NAMEOFSTUDENT');
ylabel('AGE');
title('A BAR GRAPH SHOWING AGES OF AMI CLASS');
disp('ploting is done');
%% SAVING

saveas(Q,'C:\Users\gh\Desktop\GROUP 6 MATLAB\bargraph1.png');
%% another plot

P = figure('Name','Bar');
X= A.NAMEOFSTUDENT;
Y=A.STUDENTNUMBER;
bar(X,Y);
xlabel('NAMEOFSTUDENT');
ylabel('STUDENTNUMBER');
title('A BAR GRAPH SHOWING STUDENT NUMBER OF AMI CLASS');
disp('ploting is done');
%% SAVING
saveas(P,'C:\Users\gh\Desktop\GROUP 6 MATLAB\bargraph2.png');
