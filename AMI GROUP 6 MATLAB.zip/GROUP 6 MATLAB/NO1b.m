disp('ASSIGMENT OF GROUP 6 STARTED');
%% IMPORT THE DETAILS OF AMI STUDENTS EXCELL FILE %%

disp('DETAILS OF AMI STUDENTS ');
A = readtable('C:\Users\gh\Desktop\GROUP 6 MATLAB\DETAILS OF AMI STUDENTS.xlsx' ...
    ,Sheet='DETAILS',ReadVariableNames=true);
