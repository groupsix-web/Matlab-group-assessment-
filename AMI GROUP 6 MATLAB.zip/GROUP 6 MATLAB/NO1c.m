%% EXPORTING THE EXCELL FILE %%

writetable(A,'C:\Users\gh\Desktop\GROUP 6 MATLAB\AMI GROUP6.XLSX',Sheet='DETAILS');
